nohotcorner
===========

Gnome-shell extension disabling hotcorners
